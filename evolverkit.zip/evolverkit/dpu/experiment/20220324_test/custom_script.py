#!/usr/bin/env python3

import numpy as np
import logging
import os.path
# import time

# logger setup
logger = logging.getLogger(__name__)

# USER DEFINED GENERAL SETTINGS #

# set new name for each experiment, otherwise files will be overwritten
EXP_NAME = '20220324_test'
EVOLVER_IP = '10.56.0.55'
EVOLVER_PORT = 8081

# Identify pump calibration files, define initial values for temperature, stirring, volume, power settings

# degrees C, makes 16-value list
TEMP_INITIAL = [45] * 16
# Alternatively enter 16-value list to set different values
# TEMP_INITIAL = [30,30,30,30,32,32,32,32,34,34,34,34,36,36,36,36]

# try 8,10,12 etc; makes 16-value list
STIR_INITIAL = [8] * 16
# Alternatively enter 16-value list to set different values
# STIR_INITIAL = [7,7,7,7,8,8,8,8,9,9,9,9,10,10,10,10]

VOLUME = 20  # mL, determined by vial cap straw length
PUMP_CAL_FILE = 'pump_cal.txt'  # tab delimited, mL/s with 16 influx pumps on first row, etc.
OPERATION_MODE = 'chemostat'  # use to choose between 'turbidostat' and 'chemostat' functions
# if using a different mode, name your function as the OPERATION_MODE variable

# END OF USER DEFINED GENERAL SETTINGS #


def turbidostat(eVOLVER, input_data, vials, elapsed_time):
    od_data = input_data['transformed']['od']

    # USER DEFINED VARIABLES #

    # vials is all 16, can set to different range (ex. [0,1,2,3]) to only trigger tstat on those vials
    turbidostat_vials = vials
    # set to np.inf to never stop, or integer value to stop diluting after certain number of growth curves
    stop_after_n_curves = np.inf
    # Number of values to calculate the OD average
    od_values_to_average = 6

    # to set all vials to the same value, creates 16-value list
    lower_thresh = [0.2] * len(vials)
    upper_thresh = [0.4] * len(vials)

    # Alternatively, use 16 value list to set different thresholds, use 9999 for vials not being used
    # lower_thresh = [0.2, 0.2, 0.3, 0.3, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999]
    # upper_thresh = [0.4, 0.4, 0.4, 0.4, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999]

    # END OF USER DEFINED VARIABLES #

    # Turbidostat Settings #
    # Tunable settings for overflow protection, pump scheduling etc. Unlikely to change between expts

    time_out = 5  # (sec) additional amount of time to run efflux pump
    pump_wait = 3  # (min) minimum amount of time to wait between pump events

    # End of Turbidostat Settings #

    save_path = os.path.dirname(os.path.realpath(__file__))  # save path
    flow_rate = eVOLVER.get_flow_rate()  # read from calibration file

    # Turbidostat Control Code Below #

    # fluidic message: initialized so that no change is sent
    message = ['--'] * 48
    # main loop through each vial
    for x in turbidostat_vials:
        # Update turbidostat configuration files for each vial
        # initialize OD and find OD path
        file_name = "vial{0}_ODset.txt".format(x)
        o_dset_path = os.path.join(save_path, EXP_NAME, 'o_dset', file_name)
        data = np.genfromtxt(o_dset_path, delimiter=',')
        o_dset = data[len(data)-1][1]
        o_dsettime = data[len(data)-1][0]
        num_curves = len(data)/2

        file_name = "vial{0}_OD.txt".format(x)
        od_path = os.path.join(save_path, EXP_NAME, 'OD', file_name)
        data = eVOLVER.tail_to_np(od_path, od_values_to_average)
        # average_od = 0

        # Determine whether turbidostat dilutions are needed
        # logical, checks to see if enough data points (couple minutes) for sliding window
        # enough_ODdata = (len(data) > 7)

        # logical, checks to see if enough growth curves have happened
        collecting_more_curves = (num_curves <= (stop_after_n_curves + 2))

        if data.size != 0:
            # Take median to avoid outlier
            od_values_from_file = data[:, 1]
            average_od = float(np.median(od_values_from_file))

            # if recently exceeded upper threshold, note end of growth curve in o_dset, allow dilutions to occur and
            # growthrate to be measured
            if (average_od > upper_thresh[x]) and (o_dset != lower_thresh[x]):
                text_file = open(o_dset_path, "a+")
                text_file.write("{0},{1}\n".format(elapsed_time,
                                                   lower_thresh[x]))
                text_file.close()
                o_dset = lower_thresh[x]
                # calculate growth rate
                eVOLVER.calc_growth_rate(x, o_dsettime, elapsed_time)

            # if have approx. reached lower threshold, note start of growth curve in o_dset
            if (average_od < (lower_thresh[x] + (upper_thresh[x] - lower_thresh[x]) / 3)) \
                    and (o_dset != upper_thresh[x]):
                text_file = open(o_dset_path, "a+")
                text_file.write("{0},{1}\n".format(elapsed_time, upper_thresh[x]))
                text_file.close()
                o_dset = upper_thresh[x]

            # if need to dilute to lower threshold, then calculate amount of time to pump
            if average_od > o_dset and collecting_more_curves:
                time_in = - (np.log(lower_thresh[x]/average_od)*VOLUME)/flow_rate[x]
                if time_in > 20:
                    time_in = 20

                time_in = round(time_in, 2)
                file_name = "vial{0}_pump_log.txt".format(x)
                file_path = os.path.join(save_path, EXP_NAME, 'pump_log', file_name)
                data = np.genfromtxt(file_path, delimiter=',')
                last_pump = data[len(data)-1][0]
                # if sufficient time since last pump, send command to Arduino
                if ((elapsed_time - last_pump)*60) >= pump_wait:
                    logger.info('turbidostat dilution for vial %d' % x)
                    # influx pump
                    message[x] = str(time_in)
                    # efflux pump
                    message[x + 16] = str(time_in + time_out)

                    file_name = "vial{0}_pump_log.txt".format(x)
                    file_path = os.path.join(save_path, EXP_NAME, 'pump_log', file_name)

                    text_file = open(file_path, "a+")
                    text_file.write("{0},{1}\n".format(elapsed_time, time_in))
                    text_file.close()
        else:
            logger.debug('not enough OD measurements for vial %d' % x)

    # send fluidic command only if we are actually turning on any of the pumps
    if message != ['--'] * 48:
        eVOLVER.fluid_command(message)

        # your_FB_function_here() #good spot to call feedback functions for dynamic temperature, stirring, etc for ind.
        # vials

    # your_function_here() #good spot to call non-feedback functions for dynamic temperature, stirring, etc.
    # end of turbidostat() fxn


def chemostat(eVOLVER, input_data, vials, elapsed_time):
    od_data = input_data['transformed']['od_90']

    # USER DEFINED VARIABLES #
    # ~OD600, set to 0 to start chemostat dilutions at any positive OD
    start_od = 0
    # hours, set 0 to start immediately
    start_time = 0
    # Note that script uses AND logic, so both start time and start OD must be surpassed

    # Number of values to calculate the OD average
    od_values_to_average = 6
    # vials is all 16, can set to different range (ex. [0,1,2,3]) to only trigger tstat on those vials
    chemostat_vials = vials
    # to set all vials to the same value, creates 16-value list
    rate_config = [0.5] * 16
    # UNITS of 1/hr, NOT mL/hr, rate = flowrate/volume, so dilution rate ~ growth rate, set to 0 for unused vials

    # Alternatively, use 16 value list to set different rates, use 0 for vials not being used
    # rate_config = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6]

    # END OF USER DEFINED VARIABLES #

    # Chemostat Settings #
    # Tunable settings for bolus, etc. Unlikely to change between expts
    bolus = 0.5  # mL, can be changed with great caution, 0.2 is absolute minimum

    # End of Chemostat Settings #

    # save path
    save_path = os.path.dirname(os.path.realpath(__file__))
    # read from calibration file
    flow_rate = eVOLVER.get_flow_rate()
    # initialize arrays
    period_config = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    bolus_in_s = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    # Chemostat Control Code Below #

    # main loop through each vial
    for x in chemostat_vials:
        # Update chemostat configuration files for each vial

        # initialize OD and find OD path
        file_name = "vial{0}_OD.txt".format(x)
        od_path = os.path.join(save_path, EXP_NAME, 'OD', file_name)
        data = eVOLVER.tail_to_np(od_path, od_values_to_average)
        # average_od = 0
        # logical, checks to see if enough data points (couple minutes) for sliding window
        # enough_ODdata = (len(data) > 7)

        # waits for seven OD measurements (couple minutes) for sliding window
        if data.size != 0:
            # calculate median OD
            od_values_from_file = data[:, 1]
            average_od = float(np.median(od_values_from_file))

            # set chemostat config path and pull current state from file
            file_name = "vial{0}_chemo_config.txt".format(x)
            chemoconfig_path = os.path.join(save_path, EXP_NAME, 'chemo_config', file_name)
            chemo_config = np.genfromtxt(chemoconfig_path, delimiter=',')
            # should t=0 initially, changes each time a new command is written to file
            # last_chemoset = chemo_config[len(chemo_config)-1][0]
            # should be zero initially, changes each time a new command is written to file
            last_chemophase = chemo_config[len(chemo_config)-1][1]
            # should be 0 initially, then period in seconds after new commands are sent
            last_chemorate = chemo_config[len(chemo_config)-1][2]

            # once start time has passed and culture hits start OD, if no command has been written,
            # write new chemostat command to file
            if (elapsed_time > start_time) & (average_od > start_od):
                # calculate time needed to pump bolus for each pump
                bolus_in_s[x] = bolus/flow_rate[x]
                # calculate the period (i.e. frequency of dilution events) based on user specified growth rate
                # and bolus size
                if rate_config[x] > 0:
                    # scale dilution rate by bolus size and volume
                    period_config[x] = (3600*bolus)/((rate_config[x])*VOLUME)
                else:
                    # if no dilutions needed, then just loops with no dilutions
                    period_config[x] = 0

                if last_chemorate != period_config[x]:
                    print('Chemostat updated in vial {0}'.format(x))
                    logger.info('chemostat initiated for vial %d, period %.2f' % (x, period_config[x]))
                    # writes command to chemo_config file, for storage
                    text_file = open(chemoconfig_path, "a+")
                    # note that this changes chemophase
                    text_file.write("{0},{1},{2}\n".format(elapsed_time, (last_chemophase+1), period_config[x]))
                    text_file.close()
        else:
            logger.debug('not enough OD measurements for vial %d' % x)

        # your_FB_function_here() #good spot to call feedback functions for dynamic temperature, stirring, etc for ind.
        # vials
    # your_function_here() #good spot to call non-feedback functions for dynamic temperature, stirring, etc.

    # compares computed chemostat config to the remote one
    eVOLVER.update_chemo(input_data, chemostat_vials, bolus_in_s, period_config)
    # end of chemostat() fxn

# def your_function_here(): # good spot to define modular functions for dynamics or feedback


if __name__ == '__main__':
    print('Please run eVOLVER.py instead')
