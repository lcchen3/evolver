class SocketIOError(Exception):
    pass


class ConnectionErrorEvolver(SocketIOError):
    pass


class TimeoutErrorEvolver(SocketIOError):
    pass


class PacketError(SocketIOError):
    pass
