from threading import Thread, Event

from .exceptions import ConnectionErrorEvolver, TimeoutErrorEvolver

import logging

from .symmetries import NullHandler


LOG = logging.getLogger('socketIO-client')
LOG.addHandler(NullHandler())


class HeartbeatThread(Thread):

    daemon = True

    def __init__(
            self, send_heartbeat,
            relax_interval_in_seconds,
            hurry_interval_in_seconds):
        super(HeartbeatThread, self).__init__()
        self._send_heartbeat = send_heartbeat
        self._relax_interval_in_seconds = relax_interval_in_seconds
        self._hurry_interval_in_seconds = hurry_interval_in_seconds
        self._adrenaline = Event()
        self._rest = Event()
        self._halt = Event()

    def run(self):
        try:
            while not self._halt.is_set():
                try:
                    self._send_heartbeat()
                except TimeoutErrorEvolver:
                    pass
                if self._adrenaline.is_set():
                    interval_in_seconds = self._hurry_interval_in_seconds
                else:
                    interval_in_seconds = self._relax_interval_in_seconds
                self._rest.wait(interval_in_seconds)
        except ConnectionErrorEvolver:
            LOG.debug('[heartbeat connection error]')

    def relax(self):
        self._adrenaline.clear()

    def hurry(self):
        self._adrenaline.set()
        self._rest.set()
        self._rest.clear()

    @property
    def hurried(self):
        return self._adrenaline.is_set()

    def halt(self):
        self._rest.set()
        self._halt.set()
